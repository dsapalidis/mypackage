from .geometry import Line, Point
from .utils import distance


def personal_message():
    print("Hello from Sapal!")
